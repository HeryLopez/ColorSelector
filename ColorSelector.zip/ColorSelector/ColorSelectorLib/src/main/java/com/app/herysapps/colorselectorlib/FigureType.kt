package com.app.herysapps.colorselectorlib

enum class FigureType {
    CIRCLE, SQUARE
}