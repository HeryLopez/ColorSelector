/*
 * Copyright (C) 2017 Hery Lopez
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.app.herysapps.colorselectorlib

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v4.app.FragmentManager
import android.support.v4.content.ContextCompat
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout

import java.util.ArrayList

/**
 * Github: [https://github.com/HeryLopez/ColorSelector](https://github.com/HeryLopez/ColorSelector)
 */
class ColorSelectorDialog : DialogFragment(), View.OnClickListener {

    // TODO There is an error when: 0) Select a color 1) Open the dialog. 2) While open, change the phone orientation. 3) Select a other color. 4) Reopen the dialog. Error: The indicator shows the color of the step 0.
    private lateinit var tagDialog: String

    internal var listener: OnDialogColorClickListener? = null
    internal var figureType: FigureType = FigureType.CIRCLE
    internal var title: String? = null
    internal var colorList: List<Int>? = null
    var selectedColor: Int? = null



    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putString(TITRE, title)
        outState.putInt(FIGURE, figureType.ordinal)
        selectedColor?.let { outState.putInt(SELECTED_COLOR, it) }
        outState.putIntegerArrayList(COLORS_LIST, colorList as ArrayList<Int>)
    }


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        // Get information the instance if there is.
        if (savedInstanceState != null) {
            title = savedInstanceState.getString(TITRE)
            figureType = FigureType.values()[savedInstanceState.getInt(FIGURE)]
            selectedColor = savedInstanceState.getInt(SELECTED_COLOR)
            colorList = savedInstanceState.getIntegerArrayList(COLORS_LIST)
        }

        // Build the AlertDialog
        val builderCurrency = AlertDialog.Builder(activity)
        builderCurrency.setTitle(title)

        val inflater = activity!!.layoutInflater
        val view = inflater.inflate(R.layout.activity_color_picker_adapter, null)

        buildView(view)

        builderCurrency.setView(view)

        val alertCurrency = builderCurrency.create()

        alertCurrency.setCanceledOnTouchOutside(true)
        alertCurrency.setCancelable(true)

        return alertCurrency
    }


    private fun buildView(view: View) {

        (view.findViewById(R.id.rootLayoutColorSelector) as LinearLayout).removeAllViews()
        view.setBackgroundResource(R.color.default_background_color)

        val layoutParamsContainer = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val scale = context!!.resources.displayMetrics.density
        val pixels = (50 * scale + 0.5f).toInt()

        val layoutParamsCircles = LinearLayout.LayoutParams(pixels, pixels)
        val margin = (4 * scale + 0.5f).toInt()
        layoutParamsCircles.setMargins(margin, margin, margin, margin)

        var rows = colorList!!.size / 4

        if (colorList!!.size % 4 != 0) {
            rows += 1
        }

        var index = 0

        for (i in 0 until rows) {
            val lineLayout = LinearLayout(context)
            lineLayout.gravity = Gravity.CENTER
            lineLayout.orientation = LinearLayout.HORIZONTAL
            lineLayout.layoutParams = layoutParamsContainer

            for (y in 0..3) {

                val imageButton = ImageButton(context)
                imageButton.layoutParams = layoutParamsCircles

                if (index < colorList!!.size) {
                    val colorID = colorList!![index]
                    val colorARGB = ContextCompat.getColor(context!!, colorID)

                    imageButton.tag = colorID
                    imageButton.setOnClickListener(this)

                    // Circle
                    if (figureType == FigureType.CIRCLE) {
                        imageButton.setBackgroundResource(R.drawable.circle)
                        (imageButton.background as GradientDrawable).setColor(colorARGB)

                    } else {
                        imageButton.setBackgroundColor(ContextCompat.getColor(context!!, colorID))
                    }

                    if (selectedColor == colorID) {
                        // Set the text color according to the brightness of the color
                        if (Color.red(colorARGB) + Color.green(colorARGB) + Color.blue(colorARGB) < 384) {
                            imageButton.setImageResource(R.drawable.ic_selected_white)
                        } else {
                            imageButton.setImageResource(R.drawable.ic_selected_black)
                        }
                    }

                } else {
                    imageButton.background = null
                }

                lineLayout.addView(imageButton)

                index = index + 1
            }

            (view.findViewById(R.id.rootLayoutColorSelector) as LinearLayout).addView(lineLayout)
        }

    }


    override fun onCancel(dialog: DialogInterface?) {
        super.onCancel(dialog)
    }

    override fun onClick(v: View) {

        val newColorSelected = v.tag as Int

        selectedColor = if (newColorSelected != selectedColor) {
            newColorSelected
        } else {
            // Initial color (Not selected)
            null
        }

        notifyListener()

        this.dialog.cancel()
    }


    /**
     * It notifies all classes who are listened.
     */
    private fun notifyListener() {
        listener!!.onColorClick(tagDialog, selectedColor)
    }



    /**
     * Show the dialog et set the initial value.
     *
     * @param fragmentManager see [DialogFragment.show].
     * @param tagDialog             see [DialogFragment.show].
     * @param value           initial value
     */
    fun showDialog(fragmentManager: FragmentManager, tagDialog: String, value: Double) {
        this.tagDialog = tagDialog

        // Show dialog
        show(fragmentManager, tagDialog)
    }

    companion object {
        private val COLOR_SELECTOR_NAME = "COLOR_SELECTOR_NAME"
        private val TITRE = "TITRE"
        private val FIGURE = "FIGURE"
        private val SELECTED_COLOR = "SELECTED_COLOR"
        private val COLORS_LIST = "COLORS_LIST"
    }

    interface OnDialogColorClickListener {
        fun onColorClick(tagDialog: String, selectedColor: Int?)
    }
}